from django.conf import settings
from django.shortcuts import redirect, render
import kfp
from .forms import UploadForm
from .models import KubeflowRun, MLJob
import uuid, os
from django.shortcuts import render
from django.contrib.auth.models import User
import pandas as pd
import joblib
import json
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import mean_squared_error, accuracy_score, confusion_matrix
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.contrib.auth.models import User
from io import BytesIO
from django.http import JsonResponse
from .forms import RegisterForm
from .models import CSVFile
import base64
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.http import JsonResponse
from .utils import upload_dataset_to_minio
from django.http import JsonResponse
from django.shortcuts import render
from kfp import Client
import os
# Vue pour le login
def login_view(request):
    if request.user.is_authenticated:
        return redirect('accueil')  # Rediriger les utilisateurs déjà connectés

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('accueil')
        else:
            messages.error(request, "Nom d'utilisateur ou mot de passe incorrect")
            return redirect('login')
    
    return render(request, 'core/login.html')

# Vue pour le register
def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        password_confirm = request.POST.get('password_confirm')

        if password != password_confirm:
            messages.error(request, "Les mots de passe ne correspondent pas.")
            return render(request, 'core/register.html')

        try:
            user = User.objects.create_user(username=username, password=password)
            user.save()
            messages.success(request, "Inscription réussie ! Vous pouvez maintenant vous connecter.")
            return redirect('login')
        except Exception as e:
            messages.error(request, f"Erreur lors de l'inscription : {e}")
            return render(request, 'core/register.html')

    return render(request, 'core/register.html')

# Vue pour la déconnexion
def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def uploader(request):
    return render(request, "core/uploader.html")


# from .pipeline_launcher import run_pipeline  ← tu ajouteras ça plus tard

@login_required
def success(request):
 return render(request, 'core/success.html')

@login_required
def accueil(request):
 return render(request, 'core/accueil.html')

@login_required
def executions(request):
 return render(request, 'core/executions.html')













client = kfp.Client(host="http://localhost:8080")


def run_kubeflow_pipeline(pipeline_path, dataset_path, experiment_name, run_name):
    return client.create_run_from_pipeline_package(
        pipeline_file=pipeline_path,
        arguments={"dataset_path": dataset_path},
        run_name=run_name,
        experiment_name=experiment_name
    )

def upload_dataset(request):
    if request.method == 'POST':
        dataset_file = request.FILES['dataset']
        model_type = request.POST.get('model_type')  # 'classification', 'regression', 'cnn'

        # 1. Upload vers MinIO
        s3_path = upload_dataset_to_minio(dataset_file)

        # 2. Sélectionner le pipeline selon le modèle choisi
        if model_type == "classification":
            pipeline_path = os.path.join(settings.BASE_DIR, "core", "pipelines", "classification_pipeline.yaml")
            experiment_name = "Classification Experiment"
            run_name = "classification-run"

        elif model_type == "regression":
            pipeline_path = os.path.join(settings.BASE_DIR, "core", "pipelines", "regression_pipeline.yaml")
            experiment_name = "Regression Experiment"
            run_name = "regression-run"

        elif model_type == "cnn":
            pipeline_path = os.path.join(settings.BASE_DIR, "core", "pipelines", "cnn_classification_pipeline.yaml")
            experiment_name = "CNN Classification Experiment"
            run_name = "cnn-classification-run"

        else:
            return JsonResponse({'status': 'error', 'message': 'Modèle inconnu'})

        # 3. Lancer le pipeline avec l’argument du chemin du dataset
        run = run_kubeflow_pipeline(pipeline_path, s3_path, experiment_name, run_name)
        # Stocker dans la base
        print(run.run_id)
        KubeflowRun.objects.create(
             user=request.user,
             run_id=run.run_id,
             run_name=run_name,
             experiment_name=experiment_name,
             s3_path=s3_path
)
        return JsonResponse({
            'status': 'ok',
            's3_path': s3_path,
            'run_id': run.run_id
        })

    return render(request, 'core/uploader.html')



from .models import KubeflowRun

@login_required
def list_runs(request):
    user_runs = KubeflowRun.objects.filter(user=request.user).order_by('-created_at')
    runs_data = []

    for run_entry in user_runs:
        try:
            run = client.get_run(run_id=run_entry.run_id)  # run est un objet V2beta1Run
            run_obj = run  # Parfois, c'est directement l'objet retourné

            # Extraction des infos utiles selon l'objet réel
            run_id = getattr(run_obj, "run_id", "")
            pipeline_name = getattr(getattr(run_obj, "pipeline_spec", None), "pipeline_name", "N/A")
            status = getattr(run_obj, "state", "N/A") or getattr(run_obj, "status", "N/A")
            created_at = getattr(run_obj, "create_time", "N/A")

            runs_data.append({
                'name': pipeline_name,
                'id': run_id,
                'status': status,
                'created_at': created_at,
            })
        except Exception as e:
            print(f"Erreur lors de récupération run {run_entry.run_id} : {e}")
            continue

    context = {
        'runs': runs_data,
    }
    return render(request, 'core/executions.html', context)




import boto3
import json
from urllib.parse import urlparse
from django.shortcuts import render, get_object_or_404
from .models import KubeflowRun


def run_details(request, run_id):
    # On récupère le run par son run_id (UUID), pas son id entier
    run = get_object_or_404(KubeflowRun, run_id=run_id)

    # Chemin du dataset depuis le champ enregistré
    dataset_path = run.s3_path  # Exemple: s3://mybucket/dataset.csv
    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    dataset_key = parsed.path.lstrip('/')  # ex: "dataset.csv"
    prefix = dataset_key.split('.')[0]     # ex: "dataset"

    try:
        # Connexion à MinIO
        s3 = boto3.client(
            's3',
            endpoint_url="http://localhost:9000",  # ✅ Correction ici
            aws_access_key_id="minio",
            aws_secret_access_key="minio123",
            region_name='us-east-1',
            use_ssl=False
        )

        # Lecture du fichier JSON avec les résultats du meilleur modèle
        result_key = f"{prefix}/best_model_result.json"
        response = s3.get_object(Bucket=bucket, Key=result_key)
        content = response['Body'].read().decode('utf-8')
        result_json = json.loads(content)

    except Exception as e:
        result_json = {
            "error": f"Erreur lors de la lecture du résultat : {str(e)}"
        }

    return render(request, "core/run_details.html", {
        "run": run,
        "result": result_json
    })

import boto3
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def accueil(request):
    dataset_count = 0

    try:
        # Connexion à MinIO
        s3 = boto3.client(
            's3',
            endpoint_url="http://localhost:9000",
            aws_access_key_id="minio",
            aws_secret_access_key="minio123",
            region_name='us-east-1',
            use_ssl=False
        )

        # Remplace par le nom réel de ton bucket
        bucket_name = "datasets"  # ou "mlpipeline" selon ta config

        # Lister tous les fichiers du bucket
        response = s3.list_objects_v2(Bucket=bucket_name)
        objects = response.get('Contents', [])

        # Compter les fichiers CSV
        dataset_count = sum(1 for obj in objects if obj['Key'].endswith('.csv'))

    except Exception as e:
        print("Erreur MinIO:", e)

    return render(request, 'core/accueil.html', {
        'dataset_count': dataset_count
    })
