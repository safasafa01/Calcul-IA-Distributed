from django.urls import include, path

from . import views

urlpatterns = [
    path('', views.accueil, name='accueil'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('resultats/', views.success, name='resultats'),
    path('accueil/', views.accueil, name='accueil'),
    path('executions/', views.list_runs, name='executions'),
    path('upload/', views.upload_dataset, name='uploader'),
    path("runs/<str:run_id>/", views.run_details, name="run_details"),
   
]
