from minio import Minio
from django.conf import settings
import io

def get_minio_client():
    """ Crée et retourne un client MinIO """
    client = Minio(
        endpoint=settings.MINIO_ENDPOINT,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=False,  # Définir à True si vous utilisez HTTPS
    )
    return client

def upload_file_to_minio(file, filename, model_type):
    """ Télécharge le fichier vers MinIO et crée un fichier pour le type de modèle """
    client = get_minio_client()
    bucket_name = settings.MINIO_BUCKET_NAME
    
    # Vérifier si le compartiment existe, sinon créer
    if not client.bucket_exists(bucket_name):
        client.make_bucket(bucket_name)

    # Lire le contenu du fichier
    file_data = file.read()

    # Télécharger le fichier dans le compartiment MinIO
    client.put_object(
        bucket_name, 
        filename, 
        io.BytesIO(file_data),  # Convertir les données en flux pour MinIO
        length=len(file_data),  # Utiliser la taille du fichier pour 'length'
        part_size=10*1024*1024  # Taille du morceau pour l'upload en parallèle (10 MB ici)
    )

    # Créer un fichier pour stocker le type de modèle
    model_filename = f"{filename}_model_type.txt"
    model_data = model_type.encode('utf-8')  # Convertir le type de modèle en bytes
    client.put_object(
        bucket_name,
        model_filename,
        io.BytesIO(model_data),
        length=len(model_data)
    )

    return True  # Indique que le fichier et le modèle ont été téléchargés avec succès
