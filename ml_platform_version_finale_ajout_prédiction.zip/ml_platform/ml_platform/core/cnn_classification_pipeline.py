from kfp import dsl, compiler

@dsl.component(base_image="docker.io/safa55/mon-image-kfp:latest")
def train_cnn_model(dataset_path: str) -> str:
    import boto3
    import pandas as pd
    import numpy as np
    import json
    from io import BytesIO
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Dense, Conv2D, Flatten, MaxPooling2D, Dropout
    from tensorflow.keras.utils import to_categorical
    from tensorflow.keras.callbacks import EarlyStopping
    from urllib.parse import urlparse
    import tempfile

    # --- MinIO ---
    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    key = parsed.path.lstrip('/')
    prefix = key.split('.')[0]

    s3 = boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1',
        use_ssl=False
    )

    # --- Chargement Dataset ---
    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data))
    df = df.dropna(axis=1, how='all').dropna(axis=0, how='any')

    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values
    if not np.issubdtype(y.dtype, np.number):
        y = LabelEncoder().fit_transform(y.astype(str))

    # --- Préparation CNN ---
    X = X / 255.0
    X = X.reshape(-1, 28, 28, 1)
    y = to_categorical(y)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = Sequential([
        Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(28, 28, 1)),
        MaxPooling2D(pool_size=(2, 2)),
        Flatten(),
        Dense(64, activation='relu'),
        Dropout(0.5),
        Dense(y.shape[1], activation='softmax')
    ])

    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

    early_stop = EarlyStopping(monitor='val_loss', patience=2)
    history = model.fit(X_train, y_train, epochs=10, batch_size=32, validation_split=0.1, callbacks=[early_stop])

    # Évaluation
    _, test_acc = model.evaluate(X_test, y_test)
    final_loss = history.history['loss'][-1]
    final_val_loss = history.history['val_loss'][-1]

    result = {
        "model": "CNN",
        "accuracy": float(test_acc),
        "loss": float(final_loss),
        "val_loss": float(final_val_loss)
    }

    # Sauvegarde dans MinIO
    result_json = BytesIO(json.dumps(result).encode('utf-8'))
    s3.upload_fileobj(result_json, bucket, f"{prefix}/best_model_result.json")

    return json.dumps(result)

# Définition du pipeline
@dsl.pipeline(
    name="cnn-classification-pipeline",
    description="Pipeline CNN simple pour classification"
)
def cnn_classification_pipeline(dataset_path: str):
    train_cnn_model(dataset_path=dataset_path)

# Compilation
if __name__ == "__main__":
    compiler.Compiler().compile(cnn_classification_pipeline, "cnn_classification_pipeline.yaml")
