from kfp import dsl, compiler
from kfp.dsl import component, OutputPath

# ---------- Composant KNeighborsRegressor -----------
@component(base_image="docker.io/safa55/mon-image-kfp:latest")
def gridsearch_knn_regressor(dataset_path: str) -> str:
    import boto3, pandas as pd, numpy as np, json, joblib, os
    from io import BytesIO
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.model_selection import train_test_split, GridSearchCV
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket, key = parsed.netloc, parsed.path.lstrip('/')
    prefix = os.path.splitext(key)[0]

    s3 = boto3.client('s3', endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1', use_ssl=False)

    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data)).dropna()

    for col in df.select_dtypes(include='object'):
        df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X, y = df.iloc[:, :-1], df.iloc[:, -1]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    grid = GridSearchCV(KNeighborsRegressor(), {'n_neighbors': [3, 5, 7], 'weights': ['uniform', 'distance']}, cv=3)
    grid.fit(X_train, y_train)

    best_score = grid.score(X_test, y_test)
    result = {
        'model': 'KNeighborsRegressor',
        'r2_score': best_score,
        'best_params': grid.best_params_
    }

    joblib.dump(grid.best_estimator_, "/tmp/knn_regressor.pkl")
    with open("/tmp/knn_regressor.pkl", "rb") as f:
        s3.upload_fileobj(f, bucket, f"{prefix}/knn_regressor.pkl")

    return json.dumps(result)

# ---------- Composant RandomForestRegressor -----------
@component(base_image="docker.io/safa55/mon-image-kfp:latest")
def gridsearch_randomforest_regressor(dataset_path: str) -> str:
    import boto3, pandas as pd, numpy as np, json, joblib, os
    from io import BytesIO
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import train_test_split, GridSearchCV
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket, key = parsed.netloc, parsed.path.lstrip('/')
    prefix = os.path.splitext(key)[0]

    s3 = boto3.client('s3', endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1', use_ssl=False)

    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data)).dropna()

    for col in df.select_dtypes(include='object'):
        df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X, y = df.iloc[:, :-1], df.iloc[:, -1]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    grid = GridSearchCV(RandomForestRegressor(random_state=42), {
        'n_estimators': [50, 100, 200],
        'max_depth': [5, 10, 20]
    }, cv=3)
    grid.fit(X_train, y_train)

    best_score = grid.score(X_test, y_test)
    result = {
        'model': 'RandomForestRegressor',
        'r2_score': best_score,
        'best_params': grid.best_params_
    }

    joblib.dump(grid.best_estimator_, "/tmp/rf_regressor.pkl")
    with open("/tmp/rf_regressor.pkl", "rb") as f:
        s3.upload_fileobj(f, bucket, f"{prefix}/rf_regressor.pkl")

    return json.dumps(result)

# ---------- Composant LinearRegression -----------
@component(base_image="docker.io/safa55/mon-image-kfp:latest")
def linear_regression(dataset_path: str) -> str:
    import boto3, pandas as pd, numpy as np, json, joblib, os
    from io import BytesIO
    from sklearn.linear_model import LinearRegression
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket, key = parsed.netloc, parsed.path.lstrip('/')
    prefix = os.path.splitext(key)[0]

    s3 = boto3.client('s3', endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1', use_ssl=False)

    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data)).dropna()

    for col in df.select_dtypes(include='object'):
        df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X, y = df.iloc[:, :-1], df.iloc[:, -1]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LinearRegression()
    model.fit(X_train, y_train)
    score = model.score(X_test, y_test)

    result = {
        'model': 'LinearRegression',
        'r2_score': score,
        'best_params': {}
    }

    joblib.dump(model, "/tmp/linear_regressor.pkl")
    with open("/tmp/linear_regressor.pkl", "rb") as f:
        s3.upload_fileobj(f, bucket, f"{prefix}/linear_regressor.pkl")

    return json.dumps(result)

# ---------- Composant sélection du meilleur modèle -----------
@component(base_image="docker.io/safa55/mon-image-kfp:latest")
def select_best_regressor(knn_res: str, rf_res: str, lr_res: str, dataset_path: str, output_result: OutputPath(str)):
    import json, boto3, os
    from urllib.parse import urlparse

    knn = json.loads(knn_res)
    rf = json.loads(rf_res)
    lr = json.loads(lr_res)

    best = max([knn, rf, lr], key=lambda x: x['r2_score'])

    result_data = {
        'model': best['model'],
        'r2_score': best['r2_score'],
        'best_params': best['best_params']
    }

    with open(output_result, 'w') as f:
        json.dump(result_data, f, indent=4)

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    prefix = os.path.splitext(parsed.path.lstrip('/'))[0]

    s3 = boto3.client('s3', endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1', use_ssl=False)

    s3.put_object(Bucket=bucket, Key=f"{prefix}/best_model_result.json", Body=json.dumps(result_data, indent=4))

    model_file_name = {
        'KNeighborsRegressor': 'knn_regressor.pkl',
        'RandomForestRegressor': 'rf_regressor.pkl',
        'LinearRegression': 'linear_regressor.pkl'
    }[best['model']]

    tmp_path = f"/tmp/{model_file_name}"
    s3.download_file(bucket, f"{prefix}/{model_file_name}", tmp_path)
    with open(tmp_path, "rb") as f:
        s3.upload_fileobj(f, bucket, f"{prefix}/best_model.pkl")

# ---------- Pipeline Kubeflow ----------
@dsl.pipeline(
    name="regression-pipeline-gridsearch",
    description="Pipeline de regression avec GridSearch et sauvegarde"
)
def regression_pipeline(dataset_path: str):
    knn_task = gridsearch_knn_regressor(dataset_path=dataset_path)
    rf_task = gridsearch_randomforest_regressor(dataset_path=dataset_path)
    lr_task = linear_regression(dataset_path=dataset_path)

    select_best_regressor(
        knn_res=knn_task.output,
        rf_res=rf_task.output,
        lr_res=lr_task.output,
        dataset_path=dataset_path
    )

# --------- Compiler ---------
if __name__ == "__main__":
    compiler.Compiler().compile(regression_pipeline, "regression_pipeline.yaml")