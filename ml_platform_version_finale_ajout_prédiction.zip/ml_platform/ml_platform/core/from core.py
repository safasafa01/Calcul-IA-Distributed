from models import KubeflowRun
from django.contrib.auth.models import User

user = User.objects.get(username='safa')
runs = KubeflowRun.objects.filter(user=user)
print(runs.count())
for r in runs:
    print(r.run_id, r.run_name, r.created_at)
