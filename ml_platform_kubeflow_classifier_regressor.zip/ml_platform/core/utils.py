from minio import Minio
from django.conf import settings
import uuid

def upload_dataset_to_minio(file, bucket_name="datasets"):
    client = Minio(
        settings.MINIO_ENDPOINT,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=False
    )

    if not client.bucket_exists(bucket_name):
        client.make_bucket(bucket_name)

    file_id = str(uuid.uuid4())
    object_name = f"{file_id}_{file.name}"

    client.put_object(
        bucket_name=bucket_name,
        object_name=object_name,
        data=file.file,
        length=file.size,
    )

    return f"s3://{bucket_name}/{object_name}"
