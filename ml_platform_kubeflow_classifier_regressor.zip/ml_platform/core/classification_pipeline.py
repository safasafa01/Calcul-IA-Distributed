from kfp import dsl, compiler
import json

# ----------- Composant Grid Search Logistic Regression -----------
@dsl.component(base_image="docker.io/safa55/mon-image-kfp:latest")
def gridsearch_logistic_model(dataset_path: str) -> str:
    import boto3
    import pandas as pd
    from io import BytesIO
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split, GridSearchCV
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse
    import numpy as np
    import json

    # Connexion MinIO
    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    key = parsed.path.lstrip('/')

    s3 = boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1',
        use_ssl=False
    )
    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data))

    # Nettoyage et encodage
    df = df.dropna(axis=1, how='all').dropna(axis=0, how='any')
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]
    if not np.issubdtype(y.dtype, np.number):
        y = LabelEncoder().fit_transform(y.astype(str))

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Grid Search LogisticRegression
    param_grid = {
        'C': [0.01, 0.1, 1, 10],
        'max_iter': [100, 500, 1000]
    }
    grid = GridSearchCV(LogisticRegression(), param_grid, cv=3)
    grid.fit(X_train, y_train)

    best_params = grid.best_params_
    best_score = grid.score(X_test, y_test)

    # Retour JSON sérialisé
    result = {
        'model': 'LogisticRegression',
        'accuracy': best_score,
        'best_params': best_params
    }
    return json.dumps(result)

# ----------- Composant Grid Search KNN -----------
@dsl.component(base_image="docker.io/safa55/mon-image-kfp:latest")
def gridsearch_knn_model(dataset_path: str) -> str:
    import boto3
    import pandas as pd
    from io import BytesIO
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.model_selection import train_test_split, GridSearchCV
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse
    import numpy as np
    import json

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    key = parsed.path.lstrip('/')

    s3 = boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1',
        use_ssl=False
    )
    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data))

    df = df.dropna(axis=1, how='all').dropna(axis=0, how='any')
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]
    if not np.issubdtype(y.dtype, np.number):
        y = LabelEncoder().fit_transform(y.astype(str))

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    param_grid = {
        'n_neighbors': [3, 5, 7],
        'weights': ['uniform', 'distance']
    }
    grid = GridSearchCV(KNeighborsClassifier(), param_grid, cv=3)
    grid.fit(X_train, y_train)

    best_params = grid.best_params_
    best_score = grid.score(X_test, y_test)

    result = {
        'model': 'KNN',
        'accuracy': best_score,
        'best_params': best_params
    }
    return json.dumps(result)

# ----------- Composant Grid Search AdaBoost -----------
@dsl.component(base_image="docker.io/safa55/mon-image-kfp:latest")
def gridsearch_adaboost_model(dataset_path: str) -> str:
    import boto3
    import pandas as pd
    from io import BytesIO
    from sklearn.ensemble import AdaBoostClassifier
    from sklearn.model_selection import train_test_split, GridSearchCV
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse
    import numpy as np
    import json

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    key = parsed.path.lstrip('/')

    s3 = boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1',
        use_ssl=False
    )
    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data))

    df = df.dropna(axis=1, how='all').dropna(axis=0, how='any')
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]
    if not np.issubdtype(y.dtype, np.number):
        y = LabelEncoder().fit_transform(y.astype(str))

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    param_grid = {
        'n_estimators': [50, 100, 200],
        'learning_rate': [0.01, 0.1, 1]
    }
    grid = GridSearchCV(AdaBoostClassifier(random_state=42), param_grid, cv=3)
    grid.fit(X_train, y_train)

    best_params = grid.best_params_
    best_score = grid.score(X_test, y_test)

    result = {
        'model': 'AdaBoost',
        'accuracy': best_score,
        'best_params': best_params
    }
    return json.dumps(result)

# ----------- Composant sélection du meilleur modèle -----------
@dsl.component
def select_best_model_with_params(log_res: str, knn_res: str, ada_res: str) -> str:
    import json
    log_res = json.loads(log_res)
    knn_res = json.loads(knn_res)
    ada_res = json.loads(ada_res)

    results = [log_res, knn_res, ada_res]
    best = max(results, key=lambda x: x['accuracy'])
    return (f"Best model: {best['model']} with accuracy {best['accuracy']}\n"
            f"Best hyperparameters: {best['best_params']}")

# ----------- Pipeline Kubeflow -----------

@dsl.pipeline(
    name="classification-pipeline-gridsearch",
    description="Pipeline classification avec Grid Search et sélection du meilleur modèle"
)
def classification_pipeline(dataset_path: str):
    log_task = gridsearch_logistic_model(dataset_path=dataset_path)
    knn_task = gridsearch_knn_model(dataset_path=dataset_path)
    ada_task = gridsearch_adaboost_model(dataset_path=dataset_path)

    best_task = select_best_model_with_params(
        log_res=log_task.output,
        knn_res=knn_task.output,
        ada_res=ada_task.output
    )


# ----------- Compiler -----------

if __name__ == "__main__":
    compiler.Compiler().compile(classification_pipeline, "classification_pipeline.yaml")
