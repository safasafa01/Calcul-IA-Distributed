import kfp.compiler as compiler
from classification_pipline import classification_pipeline

compiler.Compiler().compile(
    pipeline_func=classification_pipeline,
    package_path='classification_pipeline.yaml'
)
