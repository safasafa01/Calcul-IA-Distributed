from django.conf import settings
from django.shortcuts import redirect, render
from .forms import UploadForm
from .models import MLJob
from .kubeflow_client import launch_pipeline
import uuid, os
from django.shortcuts import render
from django.contrib.auth.models import User
import pandas as pd
import joblib
import json
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import mean_squared_error, accuracy_score, confusion_matrix
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.contrib.auth.models import User
from io import BytesIO
from django.http import JsonResponse
from .forms import RegisterForm
from .models import CSVFile
import base64
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.http import JsonResponse
from .utils import upload_dataset_to_minio
from django.http import JsonResponse
from django.shortcuts import render
from kfp import Client
import os
# Vue pour le login
def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')  # Rediriger les utilisateurs déjà connectés

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, "Nom d'utilisateur ou mot de passe incorrect")
            return redirect('login')
    
    return render(request, 'core/login.html')

# Vue pour le register
def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        password_confirm = request.POST.get('password_confirm')

        if password != password_confirm:
            messages.error(request, "Les mots de passe ne correspondent pas.")
            return render(request, 'core/register.html')

        try:
            user = User.objects.create_user(username=username, password=password)
            user.save()
            messages.success(request, "Inscription réussie ! Vous pouvez maintenant vous connecter.")
            return redirect('login')
        except Exception as e:
            messages.error(request, f"Erreur lors de l'inscription : {e}")
            return render(request, 'core/register.html')

    return render(request, 'core/register.html')

# Vue pour la déconnexion
def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def uploader(request):
    return render(request, "core/uploader.html")



def upload_view(request):
    if request.method == 'POST':
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            session_id = str(uuid.uuid4())
            dataset = request.FILES['dataset']
            model_type = form.cleaned_data['model_type']

            path = f'data/datasets/{session_id}/'
            os.makedirs(path, exist_ok=True)
            with open(os.path.join(path, dataset.name), 'wb+') as f:
                for chunk in dataset.chunks():
                    f.write(chunk)

            job = MLJob.objects.create(
                session_id=session_id,
                dataset_file=f'datasets/{session_id}/{dataset.name}',
                model_type=model_type,
                status='Pending'
            )

            launch_pipeline(session_id, dataset.name, model_type)

            return redirect('result_view', session_id=session_id)
    else:
        form = UploadForm()

    return render(request, 'core/uploader.html', {'form': form})

def result_view(request, session_id):
    result_dir = f'data/results/{session_id}/'
    metrics_path = os.path.join(result_dir, 'metrics.txt')
    model_path = os.path.join(result_dir, 'model.joblib')

    metrics = None
    model_url = None
    if os.path.exists(metrics_path):
        with open(metrics_path, 'r') as f:
            metrics = f.read()
    if os.path.exists(model_path):
        model_url = f'/data/results/{session_id}/model.joblib'

    return render(request, 'core/results.html', {'metrics': metrics, 'model_url': model_url})






# from .pipeline_launcher import run_pipeline  ← tu ajouteras ça plus tard

@login_required
def success(request):
 return render(request, 'core/success.html')

@login_required
def accueil(request):
 return render(request, 'core/accueil.html')

@login_required
def statistiques(request):
 return render(request, 'core/statistiques.html')
@login_required
def lancement(request):
 return render(request, 'core/lancement.html')











KUBEFLOW_HOST = "http://localhost:8080/pipeline"
client = Client(host=KUBEFLOW_HOST)

def run_kubeflow_pipeline(pipeline_path, dataset_path, experiment_name, run_name):
    return client.create_run_from_pipeline_package(
        pipeline_file=pipeline_path,
        arguments={"dataset_path": dataset_path},
        run_name=run_name,
        experiment_name=experiment_name
    )

def upload_dataset(request):
    if request.method == 'POST':
        dataset_file = request.FILES['dataset']
        model_type = request.POST.get('model_type')  # 'classification' ou 'regression'

        # 1. Upload vers MinIO
        s3_path = upload_dataset_to_minio(dataset_file)

        # 2. Sélectionner le pipeline selon le modèle choisi
        if model_type == "classification":
            pipeline_path =os.path.join(settings.BASE_DIR, "core", "pipelines", "classification_pipeline.yaml")

            experiment_name = "Classification Experiment"
            run_name = "classification-run"
        elif model_type == "regression":
            pipeline_path = os.path.join(settings.BASE_DIR, "core", "pipelines", "regression_pipeline.yaml")
            experiment_name = "Regression Experiment"
            run_name = "regression-run"
        else:
            return JsonResponse({'status': 'error', 'message': 'Modèle inconnu'})

        # 3. Lancer le pipeline avec l’argument du chemin du dataset
        run = run_kubeflow_pipeline(pipeline_path, s3_path, experiment_name, run_name)

        return JsonResponse({
            'status': 'ok',
            's3_path': s3_path,
            'run_id': run.run_id
        })

    return render(request, 'core/uploader.html')
