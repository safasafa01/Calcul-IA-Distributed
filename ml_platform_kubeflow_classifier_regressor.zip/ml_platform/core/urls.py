from django.urls import include, path

from . import views

urlpatterns = [
    path('results/<str:session_id>/', views.result_view, name='result_view'),
    path('login/', views.login_view, name='login'),
    path('', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('resultats/', views.success, name='resultats'),
    path('accueil/', views.accueil, name='accueil'),
    path('lancement/', views.lancement, name='lancement'),
    path('statistiques/', views.statistiques, name='statistiques'),
    path('upload/', views.upload_dataset, name='uploader'),

]
