from kfp import dsl, compiler
import json

# ---------- Composant KNeighborsRegressor -----------
@dsl.component(base_image="docker.io/safa55/mon-image-kfp:latest")
def gridsearch_knn_regressor(dataset_path: str) -> str:
    import boto3
    import pandas as pd
    from io import BytesIO
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.model_selection import train_test_split, GridSearchCV
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse
    import numpy as np
    import json

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    # Chargement du dataset depuis MinIO
    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    key = parsed.path.lstrip('/')

    s3 = boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1',
        use_ssl=False
    )
    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data))

    # Nettoyage et encodage
    df = df.dropna(axis=1, how='all').dropna(axis=0, how='any')
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]

    # Split train/test
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Grid Search KNeighborsRegressor
    param_grid = {
        'n_neighbors': [3, 5, 7],
        'weights': ['uniform', 'distance']
    }
    grid = GridSearchCV(KNeighborsRegressor(), param_grid, cv=3)
    grid.fit(X_train, y_train)

    best_params = grid.best_params_
    best_score = grid.score(X_test, y_test)  # R2 score

    result = {
        'model': 'KNeighborsRegressor',
        'r2_score': best_score,
        'best_params': best_params
    }
    return json.dumps(result)

# ---------- Composant RandomForestRegressor -----------
@dsl.component(base_image="docker.io/safa55/mon-image-kfp:latest")
def gridsearch_randomforest_regressor(dataset_path: str) -> str:
    import boto3
    import pandas as pd
    from io import BytesIO
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import train_test_split, GridSearchCV
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse
    import numpy as np
    import json

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    key = parsed.path.lstrip('/')

    s3 = boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1',
        use_ssl=False
    )
    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data))

    df = df.dropna(axis=1, how='all').dropna(axis=0, how='any')
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    param_grid = {
        'n_estimators': [50, 100, 200],
        'max_depth': [5, 10, 20]
    }
    grid = GridSearchCV(RandomForestRegressor(random_state=42), param_grid, cv=3)
    grid.fit(X_train, y_train)

    best_params = grid.best_params_
    best_score = grid.score(X_test, y_test)

    result = {
        'model': 'RandomForestRegressor',
        'r2_score': best_score,
        'best_params': best_params
    }
    return json.dumps(result)

# ---------- Composant LinearRegression -----------
@dsl.component(base_image="docker.io/safa55/mon-image-kfp:latest")
def linear_regression(dataset_path: str) -> str:
    import boto3
    import pandas as pd
    from io import BytesIO
    from sklearn.linear_model import LinearRegression
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    from urllib.parse import urlparse
    import numpy as np
    import json

    MINIO_ENDPOINT = "minio-service.kubeflow.svc.cluster.local:9000"
    MINIO_ACCESS_KEY = "minio"
    MINIO_SECRET_KEY = "minio123"

    parsed = urlparse(dataset_path)
    bucket = parsed.netloc
    key = parsed.path.lstrip('/')

    s3 = boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name='us-east-1',
        use_ssl=False
    )
    data = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    df = pd.read_csv(BytesIO(data))

    df = df.dropna(axis=1, how='all').dropna(axis=0, how='any')
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = LabelEncoder().fit_transform(df[col].astype(str))

    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LinearRegression()
    model.fit(X_train, y_train)
    score = model.score(X_test, y_test)

    result = {
        'model': 'LinearRegression',
        'r2_score': score,
        'best_params': {}  # pas d'hyperparamètres pour LinearRegression ici
    }
    return json.dumps(result)

# ---------- Composant pour sélectionner le meilleur modèle ----------
@dsl.component
def select_best_regressor(knn_res: str, rf_res: str, lr_res: str) -> str:
    import json

    knn = json.loads(knn_res)
    rf = json.loads(rf_res)
    lr = json.loads(lr_res)

    results = [knn, rf, lr]
    best = max(results, key=lambda x: x['r2_score'])

    return (f"Best model: {best['model']} with R2 score = {best['r2_score']}\n"
            f"Best hyperparameters: {best['best_params']}")

# ---------- Pipeline Kubeflow ----------
@dsl.pipeline(
    name="regression-pipeline-gridsearch",
    description="Pipeline de regression avec KNN, RandomForest et LinearRegression"
)
def regression_pipeline(dataset_path: str):
    knn_task = gridsearch_knn_regressor(dataset_path=dataset_path)
    rf_task = gridsearch_randomforest_regressor(dataset_path=dataset_path)
    lr_task = linear_regression(dataset_path=dataset_path)

    best_model_task = select_best_regressor(
        knn_res=knn_task.output,
        rf_res=rf_task.output,
        lr_res=lr_task.output
    )


# --------- Compiler ---------
if __name__ == "__main__":
    compiler.Compiler().compile(regression_pipeline, "regression_pipeline.yaml")
