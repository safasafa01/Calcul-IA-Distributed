import kfp
from kfp import Client

def launch_pipeline(session_id, filename, model_type):
    dataset_path = f"/mnt/data/datasets/{session_id}/{filename}"
    result_path = f"/mnt/data/results/{session_id}/"

    client = Client()  # connect to local minikube instance
    arguments = {
        'dataset_path': dataset_path,
        'model_type': model_type,
        'result_path': result_path,
    }

    client.create_run_from_pipeline_package(
        pipeline_file='core/pipelines/train_pipeline.yaml',
        arguments=arguments,
        run_name=f"Run-{session_id}"
    )
